def test_failure():
    assert True == False
